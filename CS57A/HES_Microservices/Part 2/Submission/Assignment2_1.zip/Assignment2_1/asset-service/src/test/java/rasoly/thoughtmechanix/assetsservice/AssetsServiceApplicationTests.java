package rasoly.thoughtmechanix.assetsservice;

public class AssetsServiceApplicationTests {


	public void contextLoads() {
	}

}
