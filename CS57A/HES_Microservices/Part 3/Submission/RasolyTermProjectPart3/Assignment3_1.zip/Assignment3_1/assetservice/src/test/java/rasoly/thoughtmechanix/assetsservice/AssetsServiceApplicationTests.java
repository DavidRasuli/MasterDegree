package rasoly.thoughtmechanix.assetservice;

public class AssetsServiceApplicationTests {


	public void contextLoads() {
	}

}
