package rasoly.thoughtmechanix.assetsservice.assets.services;

import org.springframework.stereotype.Service;

@Service
public class OrganizationService {
}
