Dear instructor,

I did the list at the bottom instead of on the top as suggested, I hope it is ok :)

Thanks,
David