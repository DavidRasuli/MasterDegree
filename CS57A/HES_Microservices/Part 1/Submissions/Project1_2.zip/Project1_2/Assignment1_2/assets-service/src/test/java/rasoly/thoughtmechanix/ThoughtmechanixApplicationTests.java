package rasoly.thoughtmechanix;

public class ThoughtmechanixApplicationTests {


	public void contextLoads() {
	}

}
