#!/bin/sh
echo "********************************************************"
echo "Starting sample-project "
echo "********************************************************"
java -jar /usr/local/sample-project/@project.build.finalName@.jar